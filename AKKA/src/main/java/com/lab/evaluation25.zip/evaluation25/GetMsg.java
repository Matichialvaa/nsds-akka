package com.lab.evaluation25;

public class GetMsg {

	private String name;
	
	public GetMsg (String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
}
